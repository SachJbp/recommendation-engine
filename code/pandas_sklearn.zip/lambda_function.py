from __future__ import print_function  # Makes code compatible with Python 2

import os
import ctypes

from boto3 import client, resource
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError

for d, dirs, files in os.walk('lib'):
    for f in files:
        if f.endswith('.a'):
            continue
        ctypes.cdll.LoadLibrary(os.path.join(d, f))

import pandas as pd

from sklearn.externals.joblib import load
from sklearn.metrics import pairwise_distances

db = resource("dynamodb", region_name='us-east-1')
table = db.Table('events')
s3_client = client('s3')


def handler(event, context):
    try:
        response = table.get_item(Key={'event_id': event['id'], })  # Query dynamodb for selected event
        dma_code = response['Item']['dma_code']  # Get DMA code of queried event
        relevant_events = table.query(IndexName='dma_code-index', KeyConditionExpression=Key('dma_code').eq(dma_code))
        event_df = pd.DataFrame(relevant_events['Items']).set_index('event_id')  # Add events from same DMA to pandas df
        event_descriptions = list(event_df['event_description'].values)  # Pull event descriptions
        bucket = 'recommendation-models-hc'  # Reference to S3 bucket containing trained models
        keys = {'tfidf': 'tfidf.pkl', 'svd': 'svd.pkl', 'kmeans': 'kmeans.pkl'}
        p = '/tmp/{}'.format(keys['tfidf'])
        s3_client.download_file(bucket, keys['tfidf'], p)
        tfidf = load(p)  # Load tfidf vectorizer
        vectorized_data = tfidf.transform(event_descriptions)  # Transform relevant event descriptions
        p = '/tmp/{}'.format(keys['svd'])
        s3_client.download_file(bucket, keys['svd'], p)
        svd = load(p)
        transformed_data = pd.DataFrame(svd.transform(vectorized_data), index=event_df.index)  # Transform data w/svd
        p = '/tmp/{}'.format(keys['kmeans'])
        s3_client.download_file(bucket, keys['kmeans'], p)
        kmeans = load(p)  # Load kmeans model
        clusters = pd.Series(kmeans.predict(transformed_data), index=event_df.index)  # Cluster event descriptions
        relevant_cluster = clusters[clusters == clusters.loc[event['id']]]  # Limit to events in same cluster
        distance_matrix = pd.DataFrame(pairwise_distances(
            transformed_data[transformed_data.index.isin(relevant_cluster.index)], metric='jaccard'),
            index=relevant_cluster.index, columns=relevant_cluster.index)  # Calculate pairwise jaccard distances
        possible_events = distance_matrix.loc[event['id']].drop(event['id'])  # Eliminate distance from event to itself

        return list(possible_events.sort_values().index[:5])

    except ClientError as e:
        print(e.response['Error']['Message'])
